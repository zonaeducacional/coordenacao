import {
  createBrowserRouter,
  RouterProvider,
  Route,
  createRoutesFromElements,
} from "react-router-dom";

// Layouts
import RootLayout from "./layouts/RootLayout";

// Pages
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import BoletimPage from "./pages/BoletimPage";
import NotFoundPage from "./pages/NotFoundPage";
import RelatoriosPage from "./pages/RelatoriosPage";

// Admin Pages
import AdminDashboardPage from "./pages/admin/AdminDashboardPage";
import AdminStudentsPage from "./pages/admin/AdminStudentsPage";
import AdminStudentEditPage from "./pages/admin/AdminStudentEditPage";

// Contexts
import { AuthProvider } from "./contexts/AuthContext";
import { StudentProvider } from "./contexts/StudentContext";
import { ThemeProvider } from "./contexts/ThemeContext";
import { NotificationProvider } from "./contexts/NotificationContext";

const router = createBrowserRouter(
  createRoutesFromElements(
    <Route path="/" element={<RootLayout />}>
      <Route index element={<HomePage />} />
      <Route path="login" element={<LoginPage />} />
      <Route path="register" element={<RegisterPage />} />
      <Route path="boletim" element={<BoletimPage />} />
      <Route path="relatorios" element={<RelatoriosPage />} />

      {/* Admin Routes */}
      <Route path="admin">
        <Route index element={<AdminDashboardPage />} />
        <Route path="alunos" element={<AdminStudentsPage />} />
        <Route path="alunos/:id" element={<AdminStudentEditPage />} />
        <Route path="alunos/novo" element={<AdminStudentEditPage />} />
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Route>
  )
);

function App() {
  return (
    <ThemeProvider>
      <NotificationProvider>
        <StudentProvider>
          <AuthProvider>
            <RouterProvider router={router} />
          </AuthProvider>
        </StudentProvider>
      </NotificationProvider>
    </ThemeProvider>
  );
}

export default App;
