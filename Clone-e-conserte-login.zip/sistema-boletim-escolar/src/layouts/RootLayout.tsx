import { Outlet, Link } from "react-router-dom";
import { ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useState } from "react";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import NotificationDropdown from "@/components/NotificationDropdown";

export default function RootLayout() {
  const { isAuthenticated, isAdmin, user, logout } = useAuth();
  const [dropdownOpen, setDropdownOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-200">
      <nav className="bg-white shadow-sm dark:bg-gray-800 dark:text-white transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center">
            <img
              src="/logo-escola.png"
              alt="Logo da Escola"
              className="h-10 w-auto"
            />
            <Link to="/">
              <span className="ml-2 text-xl font-semibold text-gray-900 dark:text-white">
                Escola Januário Eleodoro de Lima
              </span>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <ThemeToggle />

            {isAuthenticated && <NotificationDropdown />}

            {isAuthenticated ? (
              <>
                <div className="text-sm text-gray-600 dark:text-gray-300 hidden md:block">
                  Olá, <span className="font-medium">{user?.name}</span>
                </div>

                {isAdmin ? (
                  <div className="relative">
                    <Button
                      variant="outline"
                      onClick={() => setDropdownOpen(!dropdownOpen)}
                      className="flex items-center"
                    >
                      Administração
                      <ChevronDown className="ml-2 h-4 w-4" />
                    </Button>

                    {dropdownOpen && (
                      <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10">
                        <div className="py-1">
                          <Link
                            to="/admin"
                            className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                            onClick={() => setDropdownOpen(false)}
                          >
                            Dashboard
                          </Link>
                          <Link
                            to="/admin/alunos"
                            className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                            onClick={() => setDropdownOpen(false)}
                          >
                            Gerenciar Alunos
                          </Link>
                          <Link
                            to="/admin/alunos/novo"
                            className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                            onClick={() => setDropdownOpen(false)}
                          >
                            Novo Aluno
                          </Link>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <Link to="/boletim">
                    <Button variant="outline">Meu Boletim</Button>
                  </Link>
                )}

                <Button variant="ghost" onClick={logout}>
                  Sair
                </Button>
              </>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="outline">Entrar</Button>
                </Link>
                <Link to="/register">
                  <Button>Cadastrar</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Overlay para fechar dropdown quando clicar fora */}
      {dropdownOpen && (
        <div
          className="fixed inset-0 z-0"
          onClick={() => setDropdownOpen(false)}
        />
      )}

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 dark:text-white">
        <Outlet />
      </main>
    </div>
  );
}
