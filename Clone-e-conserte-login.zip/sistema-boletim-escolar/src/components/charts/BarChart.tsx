import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { Materia } from '@/contexts/StudentContext';

// Registrando os componentes do Chart.js
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface BarChartProps {
  materias: Materia[];
  titulo: string;
  altura?: number;
}

export default function BarChart({ materias, titulo, altura = 300 }: BarChartProps) {
  // Verificando se há matérias
  if (!materias.length) {
    return <div className="flex justify-center items-center h-64 bg-gray-50 rounded-lg">
      <p className="text-gray-500">Não há dados disponíveis para exibir o gráfico</p>
    </div>;
  }

  // Organizar as matérias em ordem alfabética para consistência
  const materiasOrdenadas = [...materias].sort((a, b) => a.nome.localeCompare(b.nome));

  // Calcular as médias
  const medias = materiasOrdenadas.map(materia => {
    const media = (materia.notas.trimestre1 + materia.notas.trimestre2 + materia.notas.trimestre3) / 3;
    return Number(media.toFixed(1));
  });

  // Preparando os dados para o gráfico
  const labels = materiasOrdenadas.map(materia => materia.nome);

  // Determinar cores com base na média (vermelho para notas baixas, amarelo para médias, verde para altas)
  const barColors = medias.map(media => {
    if (media < 5) return 'rgba(239, 68, 68, 0.7)'; // Vermelho para notas abaixo de 5
    if (media < 7) return 'rgba(245, 158, 11, 0.7)'; // Amarelo para notas entre 5 e 7
    return 'rgba(16, 185, 129, 0.7)'; // Verde para notas 7+
  });

  const borderColors = medias.map(media => {
    if (media < 5) return 'rgb(220, 38, 38)'; // Borda vermelha
    if (media < 7) return 'rgb(217, 119, 6)'; // Borda laranja
    return 'rgb(4, 120, 87)'; // Borda verde escuro
  });

  const data = {
    labels,
    datasets: [
      {
        label: 'Média Final',
        data: medias,
        backgroundColor: barColors,
        borderColor: borderColors,
        borderWidth: 1,
      },
    ],
  };

  const options: ChartOptions<'bar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: titulo,
        font: {
          size: 16,
        },
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.y !== null) {
              label += context.parsed.y.toFixed(1);
            }
            return label;
          },
          footer: function(tooltipItems) {
            const index = tooltipItems[0].dataIndex;
            const materia = materiasOrdenadas[index];
            return `Situação: ${materia.situacao}`;
          }
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 10,
        ticks: {
          stepSize: 1,
        }
      }
    }
  };

  return (
    <div style={{ height: altura }}>
      <Bar data={data} options={options} />
    </div>
  );
}
