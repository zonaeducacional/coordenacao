import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  ChartOptions,
} from 'chart.js';
import { Pie } from 'react-chartjs-2';
import { Materia } from '@/contexts/StudentContext';

// Registrando os componentes do Chart.js
ChartJS.register(
  ArcElement,
  Tooltip,
  Legend
);

interface PieChartProps {
  materias: Materia[];
  titulo: string;
  altura?: number;
}

export default function PieChart({ materias, titulo, altura = 300 }: PieChartProps) {
  // Verificando se há matérias
  if (!materias.length) {
    return <div className="flex justify-center items-center h-64 bg-gray-50 rounded-lg">
      <p className="text-gray-500">Não há dados disponíveis para exibir o gráfico</p>
    </div>;
  }

  // Contagem de situações
  const situacoes = materias.reduce((acc, materia) => {
    const situacao = materia.situacao;
    acc[situacao] = (acc[situacao] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Cores para cada situação
  const cores = {
    'Aprovado': 'rgba(16, 185, 129, 0.7)', // Verde
    'Recuperação': 'rgba(245, 158, 11, 0.7)', // Amarelo
    'Reprovado': 'rgba(239, 68, 68, 0.7)', // Vermelho
    'Em andamento': 'rgba(59, 130, 246, 0.7)', // Azul
  };

  const borderCores = {
    'Aprovado': 'rgb(4, 120, 87)', // Verde escuro
    'Recuperação': 'rgb(217, 119, 6)', // Laranja escuro
    'Reprovado': 'rgb(220, 38, 38)', // Vermelho escuro
    'Em andamento': 'rgb(29, 78, 216)', // Azul escuro
  };

  // Preparar dados para o gráfico
  const labels = Object.keys(situacoes);
  const data = Object.values(situacoes);
  const backgroundColor = labels.map(label => cores[label as keyof typeof cores] || 'gray');
  const borderColor = labels.map(label => borderCores[label as keyof typeof borderCores] || 'darkgray');

  const chartData = {
    labels,
    datasets: [
      {
        data,
        backgroundColor,
        borderColor,
        borderWidth: 1,
      },
    ],
  };

  const options: ChartOptions<'pie'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: titulo,
        font: {
          size: 16,
        },
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            const label = context.label || '';
            const value = context.raw as number;
            const percentage = ((value / materias.length) * 100).toFixed(1);
            return `${label}: ${value} (${percentage}%)`;
          }
        }
      }
    },
  };

  return (
    <div style={{ height: altura }}>
      <Pie data={chartData} options={options} />
    </div>
  );
}
