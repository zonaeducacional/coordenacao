import {
  Chart as ChartJS,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
  ChartOptions,
} from 'chart.js';
import { Radar } from 'react-chartjs-2';
import { Materia } from '@/contexts/StudentContext';

// Registrando os componentes do Chart.js
ChartJS.register(
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend
);

interface RadarChartProps {
  materias: Materia[];
  titulo: string;
  altura?: number;
}

export default function RadarChart({ materias, titulo, altura = 300 }: RadarChartProps) {
  // Verificando se há matérias
  if (!materias.length) {
    return <div className="flex justify-center items-center h-64 bg-gray-50 rounded-lg">
      <p className="text-gray-500">Não há dados disponíveis para exibir o gráfico</p>
    </div>;
  }

  if (materias.length < 3) {
    return <div className="flex justify-center items-center h-64 bg-gray-50 rounded-lg">
      <p className="text-gray-500">São necessárias pelo menos 3 disciplinas para exibir o gráfico de radar</p>
    </div>;
  }

  // Organizar as matérias em ordem alfabética para consistência
  const materiasOrdenadas = [...materias].sort((a, b) => a.nome.localeCompare(b.nome));

  // Preparando os dados para o gráfico
  const labels = materiasOrdenadas.map(materia => materia.nome);

  // Calcular médias para cada matéria
  const medias = materiasOrdenadas.map(materia => {
    const media = (materia.notas.trimestre1 + materia.notas.trimestre2 + materia.notas.trimestre3) / 3;
    return Number(media.toFixed(1));
  });

  const data = {
    labels,
    datasets: [
      {
        label: 'Médias por Disciplina',
        data: medias,
        backgroundColor: 'rgba(54, 162, 235, 0.2)',
        borderColor: 'rgb(54, 162, 235)',
        borderWidth: 2,
        pointBackgroundColor: 'rgb(54, 162, 235)',
        pointBorderColor: '#fff',
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: 'rgb(54, 162, 235)',
      },
    ],
  };

  const options: ChartOptions<'radar'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: titulo,
        font: {
          size: 16,
        },
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.r !== undefined) {
              label += context.parsed.r.toFixed(1);
            }
            return label;
          }
        }
      }
    },
    scales: {
      r: {
        angleLines: {
          display: true,
        },
        suggestedMin: 0,
        suggestedMax: 10,
        ticks: {
          stepSize: 2,
        }
      }
    }
  };

  return (
    <div style={{ height: altura }}>
      <Radar data={data} options={options} />
    </div>
  );
}
