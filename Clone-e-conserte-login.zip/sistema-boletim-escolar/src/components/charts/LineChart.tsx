import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ChartOptions,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { Materia } from '@/contexts/StudentContext';
import { useTheme } from '@/contexts/ThemeContext';

// Registrando os componentes do Chart.js
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface LineChartProps {
  materias: Materia[];
  titulo: string;
  altura?: number;
}

export default function LineChart({ materias, titulo, altura = 300 }: LineChartProps) {
  // Obter o tema atual
  const { darkMode } = useTheme();

  // Configurar cores baseadas no tema
  const textColor = darkMode ? '#e5e7eb' : '#374151';
  const gridColor = darkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';

  // Verificando se há matérias
  if (!materias.length) {
    return <div className="flex justify-center items-center h-64 bg-gray-50 dark:bg-gray-800 rounded-lg">
      <p className="text-gray-500 dark:text-gray-400">Não há dados disponíveis para exibir o gráfico</p>
    </div>;
  }

  // Organizar as matérias em ordem alfabética para consistência
  const materiasOrdenadas = [...materias].sort((a, b) => a.nome.localeCompare(b.nome));

  // Preparando os dados para o gráfico
  const labels = materiasOrdenadas.map(materia => materia.nome);

  const datasets = [
    {
      label: '1º Trimestre',
      data: materiasOrdenadas.map(materia => materia.notas.trimestre1),
      borderColor: 'rgb(59, 130, 246)', // Azul
      backgroundColor: 'rgba(59, 130, 246, 0.5)',
    },
    {
      label: '2º Trimestre',
      data: materiasOrdenadas.map(materia => materia.notas.trimestre2),
      borderColor: 'rgb(16, 185, 129)', // Verde
      backgroundColor: 'rgba(16, 185, 129, 0.5)',
    },
    {
      label: '3º Trimestre',
      data: materiasOrdenadas.map(materia => materia.notas.trimestre3),
      borderColor: 'rgb(245, 158, 11)', // Âmbar
      backgroundColor: 'rgba(245, 158, 11, 0.5)',
    },
    {
      label: 'Média',
      data: materiasOrdenadas.map(materia => {
        const media = (materia.notas.trimestre1 + materia.notas.trimestre2 + materia.notas.trimestre3) / 3;
        return Number(media.toFixed(1));
      }),
      borderColor: 'rgb(220, 38, 38)', // Vermelho
      backgroundColor: 'rgba(220, 38, 38, 0.5)',
      borderWidth: 2,
      borderDash: [5, 5],
    },
  ];

  const data = {
    labels,
    datasets,
  };

  const options: ChartOptions<'line'> = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: textColor,
          font: {
            size: 12
          }
        }
      },
      title: {
        display: true,
        text: titulo,
        color: textColor,
        font: {
          size: 16,
          weight: 'bold'
        },
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            let label = context.dataset.label || '';
            if (label) {
              label += ': ';
            }
            if (context.parsed.y !== null) {
              label += context.parsed.y.toFixed(1);
            }
            return label;
          }
        }
      }
    },
    scales: {
      x: {
        ticks: {
          color: textColor
        },
        grid: {
          color: gridColor
        }
      },
      y: {
        beginAtZero: true,
        max: 10,
        ticks: {
          stepSize: 1,
          color: textColor
        },
        grid: {
          color: gridColor
        }
      }
    }
  };

  return (
    <div style={{ height: altura }}>
      <Line data={data} options={options} />
    </div>
  );
}
