import * as React from "react";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import { Button } from "./button";

export function ThemeToggle() {
  const { darkMode, toggleDarkMode } = useTheme();

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={toggleDarkMode}
      title={darkMode ? "Mudar para modo claro" : "Mudar para modo escuro"}
      className="relative"
    >
      <Sun className={`h-5 w-5 transition-all duration-300 ${darkMode ? 'opacity-0 scale-0' : 'opacity-100 scale-100'}`} />
      <Moon className={`absolute h-5 w-5 left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 transition-all duration-300 ${darkMode ? 'opacity-100 scale-100' : 'opacity-0 scale-0'}`} />
      <span className="sr-only">Alternar tema</span>
    </Button>
  );
}
