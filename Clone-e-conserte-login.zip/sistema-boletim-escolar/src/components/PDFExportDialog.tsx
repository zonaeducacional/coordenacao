import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { FileDown, Settings } from "lucide-react";
import { Aluno } from "@/contexts/StudentContext";
import html2pdf from "html2pdf.js";

interface PDFExportDialogProps {
  targetElementId: string;
  aluno: Aluno;
  fileName?: string;
}

export default function PDFExportDialog({ targetElementId, aluno, fileName = "relatorio" }: PDFExportDialogProps) {
  const [open, setOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [orientation, setOrientation] = useState<"portrait" | "landscape">("portrait");
  const [pageSize, setPageSize] = useState("a4");
  const [includeHeader, setIncludeHeader] = useState(true);
  const [includeFooter, setIncludeFooter] = useState(true);
  const [includeInfoPanel, setIncludeInfoPanel] = useState(true);
  const [includeCharts, setIncludeCharts] = useState(true);

  const generatePDF = async () => {
    setIsExporting(true);

    try {
      // Capturar o elemento que será exportado
      const element = document.getElementById(targetElementId);
      if (!element) {
        console.error(`Elemento com ID ${targetElementId} não encontrado`);
        setIsExporting(false);
        return;
      }

      // Clonar o elemento para não afetar a exibição na tela
      const elementClone = element.cloneNode(true) as HTMLElement;

      // Se não incluir gráficos, remover os elementos
      if (!includeCharts) {
        const charts = elementClone.querySelectorAll('.chart-container');
        charts.forEach(chart => {
          chart.parentNode?.removeChild(chart);
        });
      }

      // Se não incluir painel informativo, remover
      if (!includeInfoPanel) {
        const infoPanels = elementClone.querySelectorAll('.info-panel');
        infoPanels.forEach(panel => {
          panel.parentNode?.removeChild(panel);
        });
      }

      // Criar uma div para conter o clone com estilos específicos para o PDF
      const container = document.createElement("div");
      container.style.padding = "20px";
      container.style.fontFamily = "Arial, sans-serif";

      // Adicionar cabeçalho personalizado ao PDF
      if (includeHeader) {
        const header = document.createElement("div");
        header.style.marginBottom = "20px";
        header.style.paddingBottom = "10px";
        header.style.borderBottom = "1px solid #ddd";

        const headerTitle = document.createElement("h1");
        headerTitle.style.fontSize = "24px";
        headerTitle.style.color = "#333";
        headerTitle.style.marginBottom = "10px";
        headerTitle.textContent = "Relatório de Desempenho Escolar";
        header.appendChild(headerTitle);

        const schoolName = document.createElement("h2");
        schoolName.style.fontSize = "18px";
        schoolName.style.color = "#555";
        schoolName.style.marginBottom = "10px";
        schoolName.textContent = "E.E. Januário Eleodoro de Lima";
        header.appendChild(schoolName);

        const alunoInfo = document.createElement("div");
        alunoInfo.style.marginTop = "15px";
        alunoInfo.style.fontSize = "14px";
        alunoInfo.style.color = "#555";

        alunoInfo.innerHTML = `
          <p><strong>Aluno:</strong> ${aluno.nome}</p>
          <p><strong>Matrícula:</strong> ${aluno.matricula}</p>
          <p><strong>Turma:</strong> ${aluno.turma}</p>
          <p><strong>Ano Letivo:</strong> ${aluno.ano}</p>
          <p><strong>Data:</strong> ${new Date().toLocaleDateString()}</p>
        `;
        header.appendChild(alunoInfo);

        container.appendChild(header);
      }

      // Adicionar o conteúdo clonado ao container
      container.appendChild(elementClone);

      // Adicionar rodapé
      if (includeFooter) {
        const footer = document.createElement("div");
        footer.style.marginTop = "20px";
        footer.style.paddingTop = "10px";
        footer.style.borderTop = "1px solid #ddd";
        footer.style.fontSize = "12px";
        footer.style.textAlign = "center";
        footer.style.color = "#777";
        footer.innerHTML = `
          <p>Este documento foi gerado automaticamente pelo Sistema de Boletim Escolar.</p>
          <p>Data de geração: ${new Date().toLocaleString()}</p>
        `;
        container.appendChild(footer);
      }

      // Opções para a geração do PDF
      const options = {
        margin: [10, 10],
        filename: `${fileName}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: {
          unit: 'mm',
          format: pageSize,
          orientation: orientation as 'portrait' | 'landscape'
        }
      };

      // Gerar o PDF
      await html2pdf()
        .from(container)
        .set(options)
        .save();

      console.log("PDF gerado com sucesso");
      setOpen(false);
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center" title="Exportar PDF com opções">
          <FileDown className="mr-2 h-4 w-4" />
          <Settings className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Exportar Relatório para PDF</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Orientação da Página</Label>
            <RadioGroup
              defaultValue={orientation}
              value={orientation}
              onValueChange={(value) => setOrientation(value as "portrait" | "landscape")}
              className="flex space-x-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="portrait" id="portrait" />
                <Label htmlFor="portrait">Retrato</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="landscape" id="landscape" />
                <Label htmlFor="landscape">Paisagem</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label>Tamanho do Papel</Label>
            <RadioGroup
              defaultValue={pageSize}
              value={pageSize}
              onValueChange={setPageSize}
              className="flex space-x-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="a4" id="a4" />
                <Label htmlFor="a4">A4</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="letter" id="letter" />
                <Label htmlFor="letter">Carta</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="legal" id="legal" />
                <Label htmlFor="legal">Ofício</Label>
              </div>
            </RadioGroup>
          </div>

          <Separator />

          <div className="space-y-2">
            <Label>Conteúdo a Incluir</Label>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeHeader"
                  checked={includeHeader}
                  onCheckedChange={(checked) => setIncludeHeader(checked as boolean)}
                />
                <Label htmlFor="includeHeader">Cabeçalho</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeFooter"
                  checked={includeFooter}
                  onCheckedChange={(checked) => setIncludeFooter(checked as boolean)}
                />
                <Label htmlFor="includeFooter">Rodapé</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeCharts"
                  checked={includeCharts}
                  onCheckedChange={(checked) => setIncludeCharts(checked as boolean)}
                />
                <Label htmlFor="includeCharts">Gráficos</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeInfoPanel"
                  checked={includeInfoPanel}
                  onCheckedChange={(checked) => setIncludeInfoPanel(checked as boolean)}
                />
                <Label htmlFor="includeInfoPanel">Painéis Informativos</Label>
              </div>
            </div>
          </div>
        </div>
        <div className="flex justify-end">
          <Button
            onClick={generatePDF}
            disabled={isExporting}
            className="w-full sm:w-auto"
          >
            {isExporting ? "Gerando PDF..." : "Exportar PDF"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
