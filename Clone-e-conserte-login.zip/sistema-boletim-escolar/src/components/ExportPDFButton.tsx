import { Button } from "@/components/ui/button";
import { FileDown } from "lucide-react";
import { useState } from "react";
import html2pdf from "html2pdf.js";

interface ExportPDFButtonProps {
  targetElementId: string;
  fileName?: string;
  title?: string;
  headerInfo?: {
    alunoNome: string;
    alunoMatricula: string;
    alunoTurma: string;
    alunoAno: string;
  };
}

export default function ExportPDFButton({
  targetElementId,
  fileName = "relatorio",
  title = "Relatório de Desempenho",
  headerInfo,
}: ExportPDFButtonProps) {
  const [isExporting, setIsExporting] = useState(false);

  const generatePDF = async () => {
    setIsExporting(true);

    try {
      // Capturar o elemento que será exportado
      const element = document.getElementById(targetElementId);
      if (!element) {
        console.error(`Elemento com ID ${targetElementId} não encontrado`);
        setIsExporting(false);
        return;
      }

      // Clonar o elemento para não afetar a exibição na tela
      const elementClone = element.cloneNode(true) as HTMLElement;

      // Criar uma div para conter o clone com estilos específicos para o PDF
      const container = document.createElement("div");
      container.style.padding = "20px";
      container.style.fontFamily = "Arial, sans-serif";

      // Adicionar cabeçalho personalizado ao PDF
      if (headerInfo) {
        const header = document.createElement("div");
        header.style.marginBottom = "20px";
        header.style.paddingBottom = "10px";
        header.style.borderBottom = "1px solid #ddd";

        const headerTitle = document.createElement("h1");
        headerTitle.style.fontSize = "24px";
        headerTitle.style.color = "#333";
        headerTitle.style.marginBottom = "10px";
        headerTitle.textContent = title;
        header.appendChild(headerTitle);

        const schoolName = document.createElement("h2");
        schoolName.style.fontSize = "18px";
        schoolName.style.color = "#555";
        schoolName.style.marginBottom = "10px";
        schoolName.textContent = "E.E. Januário Eleodoro de Lima";
        header.appendChild(schoolName);

        const alunoInfo = document.createElement("div");
        alunoInfo.style.marginTop = "15px";
        alunoInfo.style.fontSize = "14px";
        alunoInfo.style.color = "#555";

        alunoInfo.innerHTML = `
          <p><strong>Aluno:</strong> ${headerInfo.alunoNome}</p>
          <p><strong>Matrícula:</strong> ${headerInfo.alunoMatricula}</p>
          <p><strong>Turma:</strong> ${headerInfo.alunoTurma}</p>
          <p><strong>Ano Letivo:</strong> ${headerInfo.alunoAno}</p>
          <p><strong>Data:</strong> ${new Date().toLocaleDateString()}</p>
        `;
        header.appendChild(alunoInfo);

        container.appendChild(header);
      }

      // Adicionar o conteúdo clonado ao container
      container.appendChild(elementClone);

      // Adicionar rodapé
      const footer = document.createElement("div");
      footer.style.marginTop = "20px";
      footer.style.paddingTop = "10px";
      footer.style.borderTop = "1px solid #ddd";
      footer.style.fontSize = "12px";
      footer.style.textAlign = "center";
      footer.style.color = "#777";
      footer.innerHTML = `
        <p>Este documento foi gerado automaticamente pelo Sistema de Boletim Escolar.</p>
        <p>Data de geração: ${new Date().toLocaleString()}</p>
      `;
      container.appendChild(footer);

      // Opções para a geração do PDF
      const options = {
        margin: [10, 10],
        filename: `${fileName}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' as 'portrait' | 'landscape' }
      };

      // Gerar o PDF
      await html2pdf()
        .from(container)
        .set(options)
        .save();

      console.log("PDF gerado com sucesso");
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Button
      onClick={generatePDF}
      disabled={isExporting}
      variant="outline"
      className="flex items-center"
    >
      <FileDown className="mr-2 h-4 w-4" />
      {isExporting ? "Gerando PDF..." : "Exportar PDF"}
    </Button>
  );
}
