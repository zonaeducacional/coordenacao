import { useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useStudents } from "@/contexts/StudentContext";
import { Users, BookOpen, UserPlus } from "lucide-react";

export default function AdminDashboardPage() {
  const { isAuthenticated, isAdmin } = useAuth();
  const { alunos } = useStudents();
  const navigate = useNavigate();

  // Verificar se o usuário está autenticado e é admin
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }

    if (!isAdmin) {
      navigate("/boletim");
      return;
    }
  }, [isAuthenticated, isAdmin, navigate]);

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Painel de Administração</h1>
          <p className="text-gray-500 mt-1">Gerencie estudantes e boletins</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center">
              <Users className="mr-2 h-5 w-5 text-blue-600" />
              Alunos
            </CardTitle>
            <CardDescription>Gerenciar cadastro de alunos</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{alunos.length}</p>
            <p className="text-sm text-gray-500">alunos cadastrados</p>
          </CardContent>
          <CardFooter>
            <Link to="/admin/alunos" className="w-full">
              <Button variant="outline" className="w-full">
                Ver Alunos
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center">
              <UserPlus className="mr-2 h-5 w-5 text-green-600" />
              Novo Aluno
            </CardTitle>
            <CardDescription>Cadastrar um novo aluno</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-500">
              Adicione novos alunos ao sistema para gerenciar seus boletins
            </p>
          </CardContent>
          <CardFooter>
            <Link to="/admin/alunos/novo" className="w-full">
              <Button className="w-full">
                Cadastrar Aluno
              </Button>
            </Link>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center">
              <BookOpen className="mr-2 h-5 w-5 text-amber-600" />
              Boletins
            </CardTitle>
            <CardDescription>Gerenciar boletins</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-500">
              Acesse os boletins dos alunos para visualização ou edição
            </p>
          </CardContent>
          <CardFooter>
            <Link to="/admin/alunos" className="w-full">
              <Button variant="outline" className="w-full">
                Gerenciar Boletins
              </Button>
            </Link>
          </CardFooter>
        </Card>
      </div>

      <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
        <h2 className="text-xl font-semibold mb-4">Instruções de Uso</h2>
        <div className="space-y-3">
          <p className="text-gray-600">
            <span className="font-medium">1.</span> Gerencie alunos através da seção "Alunos"
          </p>
          <p className="text-gray-600">
            <span className="font-medium">2.</span> Cadastre novos alunos usando o botão "Cadastrar Aluno"
          </p>
          <p className="text-gray-600">
            <span className="font-medium">3.</span> Cada aluno pode acessar o sistema usando seu e-mail e senha
          </p>
          <p className="text-gray-600">
            <span className="font-medium">4.</span> Adicione matérias e notas no boletim de cada aluno
          </p>
          <p className="text-gray-600 mt-4 text-sm">
            <strong>Nota:</strong> Para testar, você pode usar as contas de alunos já cadastrados:
            <br />
            • Email: carlos@escola.com / Senha: 123456
            <br />
            • Email: ana@escola.com / Senha: 123456
          </p>
        </div>
      </div>
    </div>
  );
}
