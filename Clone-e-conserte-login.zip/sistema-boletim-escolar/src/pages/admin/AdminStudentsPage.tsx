import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/contexts/AuthContext";
import { useStudents, Aluno } from "@/contexts/StudentContext";
import { PlusCircle, Search, Pencil, Trash, BarChart } from "lucide-react";

export default function AdminStudentsPage() {
  const { isAuthenticated, isAdmin } = useAuth();
  const { alunos, deleteAluno } = useStudents();
  const navigate = useNavigate();

  // Estado para busca
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredAlunos, setFilteredAlunos] = useState<Aluno[]>(alunos);

  // Verificar se o usuário está autenticado e é admin
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }

    if (!isAdmin) {
      navigate("/boletim");
      return;
    }
  }, [isAuthenticated, isAdmin, navigate]);

  // Filtrar alunos quando o termo de busca mudar
  useEffect(() => {
    if (searchTerm.trim() === "") {
      setFilteredAlunos(alunos);
      return;
    }

    const lowerSearchTerm = searchTerm.toLowerCase();
    const filtered = alunos.filter(aluno =>
      aluno.nome.toLowerCase().includes(lowerSearchTerm) ||
      aluno.email.toLowerCase().includes(lowerSearchTerm) ||
      aluno.matricula.toLowerCase().includes(lowerSearchTerm) ||
      aluno.turma.toLowerCase().includes(lowerSearchTerm)
    );

    setFilteredAlunos(filtered);
  }, [searchTerm, alunos]);

  // Função para remover um aluno
  const handleDeleteAluno = (id: string, nome: string) => {
    if (window.confirm(`Tem certeza que deseja excluir o aluno ${nome}? Esta ação não pode ser desfeita.`)) {
      deleteAluno(id);
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Gerenciar Alunos</h1>
          <p className="text-gray-500 mt-1">Visualize, edite e cadastre alunos</p>
        </div>
        <Link to="/admin/alunos/novo">
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" /> Novo Aluno
          </Button>
        </Link>
      </div>

      {/* Barra de busca */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input
          placeholder="Buscar por nome, email, matrícula ou turma..."
          className="pl-10"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Lista de alunos */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-100 border-b">
                  <th className="text-left p-4">Matrícula</th>
                  <th className="text-left p-4">Nome</th>
                  <th className="text-left p-4">Email</th>
                  <th className="text-left p-4">Turma</th>
                  <th className="text-left p-4">Disciplinas</th>
                  <th className="text-center p-4">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filteredAlunos.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-4 text-center text-gray-500">
                      {searchTerm ? "Nenhum aluno encontrado" : "Nenhum aluno cadastrado"}
                    </td>
                  </tr>
                ) : (
                  filteredAlunos.map((aluno) => (
                    <tr key={aluno.id} className="border-b hover:bg-gray-50">
                      <td className="p-4 font-medium">{aluno.matricula}</td>
                      <td className="p-4">{aluno.nome}</td>
                      <td className="p-4">{aluno.email}</td>
                      <td className="p-4">{aluno.turma}</td>
                      <td className="p-4">{aluno.materias.length}</td>
                      <td className="p-4">
                        <div className="flex justify-center space-x-2">
                          <a
                            href={`/relatorios?id=${aluno.id}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            title="Ver Relatórios"
                          >
                            <Button
                              variant="ghost"
                              size="sm"
                            >
                              <BarChart className="h-4 w-4 text-blue-600" />
                            </Button>
                          </a>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => navigate(`/admin/alunos/${aluno.id}`)}
                            title="Editar Aluno"
                          >
                            <Pencil className="h-4 w-4 text-amber-600" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteAluno(aluno.id, aluno.nome)}
                            title="Excluir Aluno"
                          >
                            <Trash className="h-4 w-4 text-red-600" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
