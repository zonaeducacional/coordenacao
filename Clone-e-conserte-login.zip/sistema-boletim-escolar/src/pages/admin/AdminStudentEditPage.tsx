import { useEffect, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/contexts/AuthContext";
import { useStudents, Aluno, Materia } from "@/contexts/StudentContext";
import { ArrowLeft, Save, Plus, Trash, BarChart } from "lucide-react";

// Schema de validação do formulário de aluno
const studentSchema = z.object({
  nome: z.string().min(3, "O nome deve ter pelo menos 3 caracteres"),
  email: z.string().email("Formato de e-mail inválido"),
  senha: z.string().min(6, "A senha deve ter pelo menos 6 caracteres"),
  matricula: z.string().min(1, "A matrícula é obrigatória"),
  turma: z.string().min(1, "A turma é obrigatória"),
  ano: z.string().min(1, "O ano letivo é obrigatório"),
});

type StudentFormValues = z.infer<typeof studentSchema>;

// Schema de validação do formulário de matéria
const subjectSchema = z.object({
  nome: z.string().min(1, "O nome da matéria é obrigatório"),
  professor: z.string().min(1, "O nome do professor é obrigatório"),
  trimestre1: z.coerce.number().min(0, "Nota inválida").max(10, "Nota inválida"),
  trimestre2: z.coerce.number().min(0, "Nota inválida").max(10, "Nota inválida"),
  trimestre3: z.coerce.number().min(0, "Nota inválida").max(10, "Nota inválida"),
  faltas: z.coerce.number().min(0, "Número inválido"),
  situacao: z.enum(["Aprovado", "Recuperação", "Reprovado", "Em andamento"]),
});

type SubjectFormValues = z.infer<typeof subjectSchema>;

export default function AdminStudentEditPage() {
  const { isAuthenticated, isAdmin } = useAuth();
  const { getAlunoById, addAluno, updateAluno, addMateria, updateMateria, deleteMateria } = useStudents();
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();

  const [aluno, setAluno] = useState<Aluno | null>(null);
  const [activeTab, setActiveTab] = useState("dados");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  // Determinar se é edição ou criação
  const isEditing = id !== "novo" && id !== undefined;

  // Formulário principal de aluno
  const form = useForm<StudentFormValues>({
    resolver: zodResolver(studentSchema),
    defaultValues: {
      nome: "",
      email: "",
      senha: "",
      matricula: "",
      turma: "",
      ano: "",
    },
  });

  // Formulário para nova matéria
  const subjectForm = useForm<SubjectFormValues>({
    resolver: zodResolver(subjectSchema),
    defaultValues: {
      nome: "",
      professor: "",
      trimestre1: 0,
      trimestre2: 0,
      trimestre3: 0,
      faltas: 0,
      situacao: "Em andamento",
    },
  });

  // Verificar se o usuário está autenticado e é admin
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }

    if (!isAdmin) {
      navigate("/boletim");
      return;
    }

    // Se for edição, carregar os dados do aluno
    if (isEditing && id) {
      const alunoData = getAlunoById(id);
      if (alunoData) {
        setAluno(alunoData);
        form.reset({
          nome: alunoData.nome,
          email: alunoData.email,
          senha: alunoData.senha,
          matricula: alunoData.matricula,
          turma: alunoData.turma,
          ano: alunoData.ano,
        });
      } else {
        navigate("/admin/alunos");
      }
    }
  }, [isAuthenticated, isAdmin, isEditing, id, navigate, getAlunoById, form]);

  // Submissão do formulário de aluno
  const onSubmit = (data: StudentFormValues) => {
    setIsSubmitting(true);
    setSuccessMessage("");
    setErrorMessage("");

    try {
      if (isEditing && id) {
        // Atualizar aluno existente
        updateAluno(id, data);
        setSuccessMessage("Aluno atualizado com sucesso!");
      } else {
        // Adicionar novo aluno
        const novoAluno = addAluno({
          ...data,
          materias: [],
        });

        setSuccessMessage("Aluno cadastrado com sucesso!");

        // Redirecionar para a página de edição do novo aluno
        setTimeout(() => {
          navigate(`/admin/alunos/${novoAluno.id}`);
        }, 1000);
      }
    } catch (error) {
      setErrorMessage("Ocorreu um erro ao salvar os dados. Tente novamente.");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submissão do formulário de matéria
  const onAddSubject = (data: SubjectFormValues) => {
    if (!isEditing || !id) {
      setErrorMessage("Salve os dados do aluno antes de adicionar matérias.");
      return;
    }

    setIsSubmitting(true);
    setSuccessMessage("");
    setErrorMessage("");

    try {
      // Adicionar nova matéria
      const success = addMateria(id, {
        nome: data.nome,
        professor: data.professor,
        notas: {
          trimestre1: data.trimestre1,
          trimestre2: data.trimestre2,
          trimestre3: data.trimestre3,
        },
        faltas: data.faltas,
        situacao: data.situacao,
      });

      if (success) {
        // Atualizar dados do aluno na tela
        const updatedAluno = getAlunoById(id);
        if (updatedAluno) {
          setAluno(updatedAluno);
        }

        // Resetar formulário
        subjectForm.reset({
          nome: "",
          professor: "",
          trimestre1: 0,
          trimestre2: 0,
          trimestre3: 0,
          faltas: 0,
          situacao: "Em andamento",
        });

        setSuccessMessage("Matéria adicionada com sucesso!");
      } else {
        setErrorMessage("Erro ao adicionar matéria. Tente novamente.");
      }
    } catch (error) {
      setErrorMessage("Ocorreu um erro ao adicionar a matéria. Tente novamente.");
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Função para remover uma matéria
  const handleDeleteSubject = (materiaId: number) => {
    if (!isEditing || !id) return;

    const materia = aluno?.materias.find(m => m.id === materiaId);
    if (!materia) return;

    if (window.confirm(`Tem certeza que deseja excluir a matéria ${materia.nome}? Esta ação não pode ser desfeita.`)) {
      const success = deleteMateria(id, materiaId);

      if (success) {
        // Atualizar dados do aluno na tela
        const updatedAluno = getAlunoById(id);
        if (updatedAluno) {
          setAluno(updatedAluno);
        }

        setSuccessMessage("Matéria removida com sucesso!");
      } else {
        setErrorMessage("Erro ao remover matéria. Tente novamente.");
      }
    }
  };

  // Função para calcular a média de uma matéria
  const calcularMedia = (notas: Materia["notas"]) => {
    return ((notas.trimestre1 + notas.trimestre2 + notas.trimestre3) / 3).toFixed(1);
  };

  return (
    <div>
      <div className="flex items-center mb-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate("/admin/alunos")}
          className="p-0 mr-2"
        >
          <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
        </Button>
      </div>

      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            {isEditing ? `Editar Aluno: ${aluno?.nome}` : "Cadastrar Novo Aluno"}
          </h1>
          <p className="text-gray-500 mt-1">
            {isEditing
              ? "Atualize os dados do aluno e gerencie suas disciplinas"
              : "Preencha os dados para cadastrar um novo aluno"
            }
          </p>
        </div>
        {isEditing && (
          <Link to={`/relatorios?id=${id}`}>
            <Button variant="outline" className="flex items-center">
              <BarChart className="mr-2 h-4 w-4" />
              Ver Relatórios
            </Button>
          </Link>
        )}
      </div>

      {/* Mensagens de sucesso/erro */}
      {successMessage && (
        <div className="mb-4 p-3 bg-green-50 border border-green-200 text-green-700 rounded-md">
          {successMessage}
        </div>
      )}

      {errorMessage && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-md">
          {errorMessage}
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList>
          <TabsTrigger value="dados">Dados do Aluno</TabsTrigger>
          {isEditing && <TabsTrigger value="materias">Matérias</TabsTrigger>}
        </TabsList>

        {/* Tab de dados do aluno */}
        <TabsContent value="dados">
          <Card>
            <CardHeader>
              <CardTitle>Informações Pessoais</CardTitle>
              <CardDescription>
                Preencha os dados cadastrais do aluno
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="nome"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome Completo</FormLabel>
                          <FormControl>
                            <Input placeholder="Nome do aluno" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="email@escola.com" type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="senha"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Senha</FormLabel>
                          <FormControl>
                            <Input placeholder="******" type="password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="matricula"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Matrícula</FormLabel>
                          <FormControl>
                            <Input placeholder="Número de matrícula" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="turma"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Turma</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: 9º Ano A" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="ano"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ano Letivo</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: 2023" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Button type="submit" className="mt-4" disabled={isSubmitting}>
                    <Save className="mr-2 h-4 w-4" />
                    {isSubmitting ? "Salvando..." : "Salvar Dados"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab de matérias - apenas para edição */}
        {isEditing && (
          <TabsContent value="materias">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Lista de matérias */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Disciplinas do Aluno</CardTitle>
                    <CardDescription>
                      {aluno?.materias.length
                        ? `${aluno.materias.length} disciplinas cadastradas`
                        : "Nenhuma disciplina cadastrada"
                      }
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {aluno?.materias.length === 0 ? (
                      <div className="text-center py-6 text-gray-500">
                        Nenhuma disciplina cadastrada para este aluno.
                        <br />
                        Use o formulário ao lado para adicionar disciplinas.
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse">
                          <thead>
                            <tr className="bg-gray-100">
                              <th className="p-2 text-left border border-gray-200">Disciplina</th>
                              <th className="p-2 text-left border border-gray-200">Professor</th>
                              <th className="p-2 text-center border border-gray-200">Média</th>
                              <th className="p-2 text-center border border-gray-200">Faltas</th>
                              <th className="p-2 text-center border border-gray-200">Situação</th>
                              <th className="p-2 text-center border border-gray-200"></th>
                            </tr>
                          </thead>
                          <tbody>
                            {aluno?.materias.map(materia => (
                              <tr key={materia.id} className="hover:bg-gray-50">
                                <td className="p-2 border border-gray-200 font-medium">{materia.nome}</td>
                                <td className="p-2 border border-gray-200">{materia.professor}</td>
                                <td className="p-2 text-center border border-gray-200">{calcularMedia(materia.notas)}</td>
                                <td className="p-2 text-center border border-gray-200">{materia.faltas}</td>
                                <td className={`p-2 text-center border border-gray-200 font-medium ${
                                  materia.situacao === "Aprovado"
                                    ? "text-green-600"
                                    : materia.situacao === "Reprovado"
                                    ? "text-red-600"
                                    : "text-yellow-600"
                                }`}>
                                  {materia.situacao}
                                </td>
                                <td className="p-2 text-center border border-gray-200">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleDeleteSubject(materia.id)}
                                    title="Remover Disciplina"
                                  >
                                    <Trash className="h-4 w-4 text-red-600" />
                                  </Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Formulário para adicionar matéria */}
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>Adicionar Disciplina</CardTitle>
                    <CardDescription>
                      Adicione uma nova disciplina ao boletim
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...subjectForm}>
                      <form onSubmit={subjectForm.handleSubmit(onAddSubject)} className="space-y-4">
                        <FormField
                          control={subjectForm.control}
                          name="nome"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Nome da Disciplina</FormLabel>
                              <FormControl>
                                <Input placeholder="Ex: Matemática" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={subjectForm.control}
                          name="professor"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Professor</FormLabel>
                              <FormControl>
                                <Input placeholder="Nome do professor" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-3 gap-2">
                          <FormField
                            control={subjectForm.control}
                            name="trimestre1"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>1º Trim.</FormLabel>
                                <FormControl>
                                  <Input placeholder="0.0" type="number" min="0" max="10" step="0.1" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={subjectForm.control}
                            name="trimestre2"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>2º Trim.</FormLabel>
                                <FormControl>
                                  <Input placeholder="0.0" type="number" min="0" max="10" step="0.1" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={subjectForm.control}
                            name="trimestre3"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>3º Trim.</FormLabel>
                                <FormControl>
                                  <Input placeholder="0.0" type="number" min="0" max="10" step="0.1" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <FormField
                            control={subjectForm.control}
                            name="faltas"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Faltas</FormLabel>
                                <FormControl>
                                  <Input placeholder="0" type="number" min="0" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={subjectForm.control}
                            name="situacao"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Situação</FormLabel>
                                <FormControl>
                                  <select
                                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                    {...field}
                                  >
                                    <option value="Em andamento">Em andamento</option>
                                    <option value="Aprovado">Aprovado</option>
                                    <option value="Recuperação">Recuperação</option>
                                    <option value="Reprovado">Reprovado</option>
                                  </select>
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <Button type="submit" className="w-full mt-4" disabled={isSubmitting}>
                          <Plus className="mr-2 h-4 w-4" />
                          {isSubmitting ? "Adicionando..." : "Adicionar Disciplina"}
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}
