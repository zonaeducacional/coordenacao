import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function NotFoundPage() {
  return (
    <div className="flex flex-col items-center justify-center text-center py-20">
      <h1 className="text-6xl font-bold text-gray-900 mb-6">404</h1>
      <h2 className="text-3xl font-semibold text-gray-800 mb-4">Página não encontrada</h2>
      <p className="text-lg text-gray-600 max-w-md mb-8">
        Parece que você seguiu um link quebrado ou digitou um URL que não existe neste site.
      </p>
      <Link to="/">
        <Button size="lg">Voltar para o início</Button>
      </Link>
    </div>
  );
}
