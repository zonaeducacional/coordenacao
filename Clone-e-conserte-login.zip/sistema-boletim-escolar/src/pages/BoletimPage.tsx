import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { useStudents, Aluno } from "@/contexts/StudentContext";
import { BarChart } from "lucide-react";

export default function BoletimPage() {
  const navigate = useNavigate();
  const { user, isAuthenticated, logout } = useAuth();
  const { getAlunoById } = useStudents();
  const [aluno, setAluno] = useState<Aluno | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Verificar se o usuário está autenticado
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }

    // Se for admin, redirecionar para o painel de administração
    if (user?.role === "admin") {
      navigate("/admin");
      return;
    }

    // Buscar dados do aluno logado
    if (user?.role === "student" && user?.id) {
      const alunoData = getAlunoById(user.id);
      if (alunoData) {
        setAluno(alunoData);
      } else {
        // Caso não encontre o aluno, fazer logout
        logout();
        navigate("/login");
      }
    }

    setIsLoading(false);
  }, [isAuthenticated, user, navigate, logout, getAlunoById]);

  const calcularMedia = (notas: { trimestre1: number; trimestre2: number; trimestre3: number }) => {
    return ((notas.trimestre1 + notas.trimestre2 + notas.trimestre3) / 3).toFixed(1);
  };

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  if (isLoading) {
    return <div className="text-center py-10">Carregando...</div>;
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Boletim Escolar</h1>
          <p className="text-gray-500">Ano Letivo: {aluno?.ano}</p>
        </div>
        <div className="flex space-x-3">
          <Link to="/relatorios">
            <Button variant="outline" className="flex items-center">
              <BarChart className="mr-2 h-4 w-4" />
              Ver Relatórios
            </Button>
          </Link>
          <Button variant="outline" onClick={handleLogout}>
            Sair
          </Button>
        </div>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Dados do Aluno</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">Nome</p>
              <p className="font-medium">{aluno?.nome}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Turma</p>
              <p className="font-medium">{aluno?.turma}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Matrícula</p>
              <p className="font-medium">{aluno?.matricula}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <h2 className="text-xl font-bold text-gray-900 mb-4">Notas por Disciplina</h2>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-3 text-left border border-gray-200">Disciplina</th>
              <th className="p-3 text-left border border-gray-200">Professor</th>
              <th className="p-3 text-center border border-gray-200">1º Trimestre</th>
              <th className="p-3 text-center border border-gray-200">2º Trimestre</th>
              <th className="p-3 text-center border border-gray-200">3º Trimestre</th>
              <th className="p-3 text-center border border-gray-200">Média</th>
              <th className="p-3 text-center border border-gray-200">Faltas</th>
              <th className="p-3 text-center border border-gray-200">Situação</th>
            </tr>
          </thead>
          <tbody>
            {aluno?.materias.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-4 text-center text-gray-500">
                  Nenhuma disciplina registrada no boletim
                </td>
              </tr>
            ) : (
              aluno?.materias.map((materia) => (
                <tr key={materia.id} className="hover:bg-gray-50">
                  <td className="p-3 border border-gray-200 font-medium">{materia.nome}</td>
                  <td className="p-3 border border-gray-200">{materia.professor}</td>
                  <td className="p-3 text-center border border-gray-200">{materia.notas.trimestre1.toFixed(1)}</td>
                  <td className="p-3 text-center border border-gray-200">{materia.notas.trimestre2.toFixed(1)}</td>
                  <td className="p-3 text-center border border-gray-200">{materia.notas.trimestre3.toFixed(1)}</td>
                  <td className="p-3 text-center border border-gray-200 font-medium">
                    {calcularMedia(materia.notas)}
                  </td>
                  <td className="p-3 text-center border border-gray-200">{materia.faltas}</td>
                  <td className={`p-3 text-center border border-gray-200 font-medium ${
                    materia.situacao === "Aprovado"
                      ? "text-green-600"
                      : materia.situacao === "Reprovado"
                      ? "text-red-600"
                      : "text-yellow-600"
                  }`}>
                    {materia.situacao}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-8 bg-gray-50 p-4 rounded-md">
        <h3 className="font-semibold mb-2">Legenda:</h3>
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-600 rounded-full mr-2"></div>
            <p className="text-sm">Aprovado: Média ≥ 7,0</p>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-yellow-600 rounded-full mr-2"></div>
            <p className="text-sm">Recuperação: Média entre 5,0 e 6,9</p>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-600 rounded-full mr-2"></div>
            <p className="text-sm">Reprovado: Média &lt; 5,0</p>
          </div>
        </div>
      </div>
    </div>
  );
}
