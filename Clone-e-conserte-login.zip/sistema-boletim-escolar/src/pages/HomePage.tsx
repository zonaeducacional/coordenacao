import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export default function HomePage() {
  return (
    <div>
      <div className="flex flex-col items-center text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
          Sistema de Boletim Escolar
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl">
          Acesse as notas e o desempenho escolar de forma fácil e rápida. Nossa plataforma
          oferece um sistema completo para acompanhamento do progresso acadêmico.
        </p>
        <Button asChild className="mt-8">
          <Link to="/login">Acessar Boletim</Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Notas Online</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Acesse as notas de todas as disciplinas de forma digital e organizada.
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Histórico Escolar</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Visualize o histórico completo do desempenho acadêmico.
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold mb-4 text-gray-900 dark:text-white">Acompanhamento</h2>
          <p className="text-gray-600 dark:text-gray-400">
            Monitore o progresso e desenvolvimento ao longo do ano letivo.
          </p>
        </div>
      </div>
    </div>
  );
}
