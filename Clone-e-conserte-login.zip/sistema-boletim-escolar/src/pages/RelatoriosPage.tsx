import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { useStudents, Aluno } from "@/contexts/StudentContext";
import LineChart from "@/components/charts/LineChart";
import BarChart from "@/components/charts/BarChart";
import RadarChart from "@/components/charts/RadarChart";
import PieChart from "@/components/charts/PieChart";
import ExportPDFButton from "@/components/ExportPDFButton";
import PDFExportDialog from "@/components/PDFExportDialog";
import { ArrowLeft, BarChart as BarChartIcon, LineChart as LineChartIcon, PieChart as PieChartIcon, Radar, FileDown } from "lucide-react";

export default function RelatoriosPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, isAuthenticated, isAdmin } = useAuth();
  const { getAlunoById, alunos } = useStudents();
  const [aluno, setAluno] = useState<Aluno | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Verificar se o usuário está autenticado
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login");
      return;
    }

    // Obter o ID do aluno da URL de forma mais robusta
    const params = new URLSearchParams(location.search);
    const alunoId = params.get('id');

    if (isAdmin) {
      // Se for admin e há um ID na URL, mostrar relatórios do aluno específico
      if (alunoId) {
        console.log("Admin acessando relatório do aluno ID:", alunoId);
        const alunoData = getAlunoById(alunoId);
        if (alunoData) {
          setAluno(alunoData);
        } else {
          console.error("Aluno não encontrado com ID:", alunoId);
          navigate("/admin/alunos");
        }
      } else {
        // Se não houver ID, mostrar o primeiro aluno como exemplo
        if (alunos.length > 0) {
          setAluno(alunos[0]);
        }
      }
    } else if (user?.role === "student" && user?.id) {
      // Se for aluno, mostrar apenas seus próprios dados
      const alunoData = getAlunoById(user.id);
      if (alunoData) {
        setAluno(alunoData);
      } else {
        // Caso não encontre o aluno, fazer logout
        navigate("/boletim");
      }
    }

    setIsLoading(false);
  }, [isAuthenticated, user, navigate, isAdmin, getAlunoById, alunos, location.search]);

  // Calcular estatísticas para o card de resumo
  const calcularEstatisticas = () => {
    if (!aluno || !aluno.materias.length) return null;

    const medias = aluno.materias.map(materia => {
      return (materia.notas.trimestre1 + materia.notas.trimestre2 + materia.notas.trimestre3) / 3;
    });

    const mediaGeral = medias.reduce((sum, media) => sum + media, 0) / medias.length;
    const melhorNota = Math.max(...medias);
    const piorNota = Math.min(...medias);

    const aprovadas = aluno.materias.filter(m => m.situacao === "Aprovado").length;
    const recuperacao = aluno.materias.filter(m => m.situacao === "Recuperação").length;
    const reprovadas = aluno.materias.filter(m => m.situacao === "Reprovado").length;
    const emAndamento = aluno.materias.filter(m => m.situacao === "Em andamento").length;

    return {
      mediaGeral: mediaGeral.toFixed(1),
      melhorNota: melhorNota.toFixed(1),
      piorNota: piorNota.toFixed(1),
      aprovadas,
      recuperacao,
      reprovadas,
      emAndamento,
      total: aluno.materias.length
    };
  };

  const estatisticas = calcularEstatisticas();

  if (isLoading) {
    return <div className="text-center py-10">Carregando...</div>;
  }

  if (!aluno) {
    return (
      <div className="text-center py-10">
        <h2 className="text-xl font-bold mb-4">Nenhum aluno encontrado para exibir relatórios</h2>
        <Button onClick={() => navigate(isAdmin ? "/admin/alunos" : "/boletim")}>
          Voltar
        </Button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate(isAdmin ? `/admin/alunos/${aluno.id}` : "/boletim")}
          className="flex items-center"
        >
          <ArrowLeft className="h-4 w-4 mr-1" /> Voltar
        </Button>

        <div className="flex space-x-2">
          <PDFExportDialog
            targetElementId="relatorioPDF"
            aluno={aluno}
            fileName={`relatorio_${aluno.nome.toLowerCase().replace(/\s+/g, '_')}`}
          />

          <ExportPDFButton
            targetElementId="relatorioPDF"
            fileName={`relatorio_${aluno.nome.toLowerCase().replace(/\s+/g, '_')}`}
            title="Relatório de Desempenho Escolar"
            headerInfo={{
              alunoNome: aluno.nome,
              alunoMatricula: aluno.matricula,
              alunoTurma: aluno.turma,
              alunoAno: aluno.ano
            }}
          />
        </div>
      </div>

      <div id="relatorioPDF">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Relatórios de Desempenho</h1>
            <p className="text-gray-500 dark:text-gray-400 mt-1">
              {isAdmin
                ? `Visualização de desempenho do aluno: ${aluno.nome}`
                : "Visualize seu desempenho acadêmico"
              }
            </p>
          </div>
        </div>

        {/* Cards de Resumo */}
        {estatisticas && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card className="bg-blue-50 dark:bg-blue-900/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center text-blue-700 dark:text-blue-300">
                  <LineChartIcon className="mr-2 h-5 w-5" />
                  Média Geral
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-blue-700 dark:text-blue-300">{estatisticas.mediaGeral}</p>
                <p className="text-sm text-blue-600 dark:text-blue-400">De 0 a 10</p>
              </CardContent>
            </Card>

            <Card className="bg-green-50 dark:bg-green-900/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center text-green-700 dark:text-green-300">
                  <BarChartIcon className="mr-2 h-5 w-5" />
                  Disciplinas Aprovadas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-green-700 dark:text-green-300">{estatisticas.aprovadas}</p>
                <p className="text-sm text-green-600 dark:text-green-400">De {estatisticas.total} disciplinas</p>
              </CardContent>
            </Card>

            <Card className="bg-yellow-50 dark:bg-yellow-900/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center text-yellow-700 dark:text-yellow-300">
                  <PieChartIcon className="mr-2 h-5 w-5" />
                  Melhor Nota
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-yellow-700 dark:text-yellow-300">{estatisticas.melhorNota}</p>
                <p className="text-sm text-yellow-600 dark:text-yellow-400">De 0 a 10</p>
              </CardContent>
            </Card>

            <Card className="bg-red-50 dark:bg-red-900/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center text-red-700 dark:text-red-300">
                  <Radar className="mr-2 h-5 w-5" />
                  Pior Nota
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-red-700 dark:text-red-300">{estatisticas.piorNota}</p>
                <p className="text-sm text-red-600 dark:text-red-400">De 0 a 10</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Gráficos */}
        <div className="space-y-8">
          {/* Evolução por Trimestre */}
          <Card>
            <CardHeader>
              <CardTitle>Evolução das Notas por Trimestre</CardTitle>
            </CardHeader>
            <CardContent className="chart-container">
              <LineChart
                materias={aluno.materias}
                titulo="Notas e Médias por Disciplina"
                altura={400}
              />
            </CardContent>
          </Card>

          {/* Média Final por Disciplina */}
          <Card>
            <CardHeader>
              <CardTitle>Médias por Disciplina</CardTitle>
            </CardHeader>
            <CardContent className="chart-container">
              <BarChart
                materias={aluno.materias}
                titulo="Comparativo de Médias Finais"
                altura={400}
              />
            </CardContent>
          </Card>

          {/* Gráfico de Radar */}
          <Card>
            <CardHeader>
              <CardTitle>Perfil de Desempenho</CardTitle>
            </CardHeader>
            <CardContent className="chart-container">
              <RadarChart
                materias={aluno.materias}
                titulo="Análise de Desempenho por Área"
                altura={400}
              />
            </CardContent>
          </Card>

          {/* Gráfico de Pizza */}
          <Card>
            <CardHeader>
              <CardTitle>Distribuição por Situação</CardTitle>
            </CardHeader>
            <CardContent className="chart-container">
              <PieChart
                materias={aluno.materias}
                titulo="Situação das Disciplinas"
                altura={300}
              />
            </CardContent>
          </Card>
        </div>

        <div className="mt-8 bg-gray-50 dark:bg-gray-800 p-4 rounded-md info-panel">
          <h3 className="font-semibold mb-2">Informações Adicionais:</h3>
          <p className="text-gray-600 dark:text-gray-300 mb-2">
            Os gráficos acima fornecem uma visão detalhada do seu desempenho acadêmico,
            permitindo identificar pontos fortes e áreas que precisam de mais atenção.
          </p>
          <p className="text-gray-600 dark:text-gray-300">
            <span className="font-medium">Média mínima para aprovação:</span> 7,0
            <br />
            <span className="font-medium">Recuperação:</span> Entre 5,0 e 6,9
            <br />
            <span className="font-medium">Reprovação:</span> Abaixo de 5,0
          </p>
        </div>
      </div>
    </div>
  );
}
