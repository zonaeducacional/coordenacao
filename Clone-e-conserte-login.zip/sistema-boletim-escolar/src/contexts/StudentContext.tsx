import { createContext, useState, useContext, useEffect, ReactNode } from "react";
import { useNotifications } from "./NotificationContext";

// Tipos
export interface Materia {
  id: number;
  nome: string;
  professor: string;
  notas: {
    trimestre1: number;
    trimestre2: number;
    trimestre3: number;
  };
  faltas: number;
  situacao: "Aprovado" | "Recuperação" | "Reprovado" | "Em andamento";
}

export interface Aluno {
  id: string;
  nome: string;
  email: string;
  senha: string;
  matricula: string;
  turma: string;
  ano: string;
  materias: Materia[];
}

// Interface do contexto
interface StudentContextType {
  alunos: Aluno[];
  getAlunoById: (id: string) => Aluno | undefined;
  getAlunoByEmail: (email: string) => Aluno | undefined;
  addAluno: (aluno: Omit<Aluno, "id">) => Aluno;
  updateAluno: (id: string, data: Partial<Aluno>) => boolean;
  deleteAluno: (id: string) => boolean;
  addMateria: (alunoId: string, materia: Omit<Materia, "id">) => boolean;
  updateMateria: (alunoId: string, materiaId: number, data: Partial<Materia>) => boolean;
  deleteMateria: (alunoId: string, materiaId: number) => boolean;
}

// Dados iniciais
const dadosAlunosIniciais: Aluno[] = [
  {
    id: "1",
    nome: "Carlos Eduardo Silva",
    email: "carlos@escola.com",
    senha: "123456",
    matricula: "2023001",
    turma: "9º Ano A",
    ano: "2023",
    materias: [
      {
        id: 1,
        nome: "Matemática",
        professor: "Ana Oliveira",
        notas: {
          trimestre1: 8.5,
          trimestre2: 7.0,
          trimestre3: 9.0,
        },
        faltas: 2,
        situacao: "Aprovado",
      },
      {
        id: 2,
        nome: "Português",
        professor: "Carlos Pereira",
        notas: {
          trimestre1: 7.0,
          trimestre2: 6.5,
          trimestre3: 8.0,
        },
        faltas: 3,
        situacao: "Aprovado",
      },
      {
        id: 3,
        nome: "História",
        professor: "Mariana Costa",
        notas: {
          trimestre1: 6.0,
          trimestre2: 6.0,
          trimestre3: 7.5,
        },
        faltas: 5,
        situacao: "Aprovado",
      },
    ],
  },
  {
    id: "2",
    nome: "Ana Beatriz Souza",
    email: "ana@escola.com",
    senha: "123456",
    matricula: "2023002",
    turma: "9º Ano A",
    ano: "2023",
    materias: [
      {
        id: 1,
        nome: "Matemática",
        professor: "Ana Oliveira",
        notas: {
          trimestre1: 9.5,
          trimestre2: 9.0,
          trimestre3: 9.5,
        },
        faltas: 0,
        situacao: "Aprovado",
      },
      {
        id: 2,
        nome: "Português",
        professor: "Carlos Pereira",
        notas: {
          trimestre1: 8.0,
          trimestre2: 8.5,
          trimestre3: 9.0,
        },
        faltas: 1,
        situacao: "Aprovado",
      },
    ],
  },
];

// Criar contexto
const StudentContext = createContext<StudentContextType | undefined>(undefined);

// Provider
interface StudentProviderProps {
  children: ReactNode;
}

export function StudentProvider({ children }: StudentProviderProps) {
  const { addNotification } = useNotifications();

  // Estado para armazenar os alunos
  const [alunos, setAlunos] = useState<Aluno[]>(() => {
    const dadosSalvos = localStorage.getItem("alunos");
    return dadosSalvos ? JSON.parse(dadosSalvos) : dadosAlunosIniciais;
  });

  // Salvar dados no localStorage quando mudar
  useEffect(() => {
    localStorage.setItem("alunos", JSON.stringify(alunos));
  }, [alunos]);

  // Obter um aluno pelo ID
  const getAlunoById = (id: string) => {
    return alunos.find(aluno => aluno.id === id);
  };

  // Obter um aluno pelo e-mail
  const getAlunoByEmail = (email: string) => {
    return alunos.find(aluno => aluno.email === email);
  };

  // Adicionar um novo aluno
  const addAluno = (aluno: Omit<Aluno, "id">) => {
    const novoAluno: Aluno = {
      ...aluno,
      id: Date.now().toString(),
    };

    setAlunos(prev => [...prev, novoAluno]);

    // Notificação para o administrador
    addNotification({
      title: "Novo Aluno Cadastrado",
      message: `O aluno ${novoAluno.nome} foi cadastrado com sucesso.`,
      type: "success",
    });

    return novoAluno;
  };

  // Atualizar um aluno
  const updateAluno = (id: string, data: Partial<Aluno>) => {
    let sucesso = false;

    setAlunos(prev => {
      const index = prev.findIndex(aluno => aluno.id === id);

      if (index !== -1) {
        const alunosAtualizados = [...prev];
        alunosAtualizados[index] = { ...alunosAtualizados[index], ...data };
        sucesso = true;
        return alunosAtualizados;
      }

      return prev;
    });

    if (sucesso) {
      // Notificação para o administrador
      addNotification({
        title: "Aluno Atualizado",
        message: `Os dados do aluno foram atualizados com sucesso.`,
        type: "info",
      });
    }

    return sucesso;
  };

  // Excluir um aluno
  const deleteAluno = (id: string) => {
    let alunoExcluido: Aluno | undefined;

    setAlunos(prev => {
      const alunoIndex = prev.findIndex(aluno => aluno.id === id);
      if (alunoIndex !== -1) {
        alunoExcluido = prev[alunoIndex];
        const newAlunos = [...prev];
        newAlunos.splice(alunoIndex, 1);
        return newAlunos;
      }
      return prev;
    });

    if (alunoExcluido) {
      // Notificação para o administrador
      addNotification({
        title: "Aluno Excluído",
        message: `O aluno ${alunoExcluido.nome} foi excluído do sistema.`,
        type: "warning",
      });
      return true;
    }

    return false;
  };

  // Adicionar uma matéria a um aluno
  const addMateria = (alunoId: string, materia: Omit<Materia, "id">) => {
    let sucesso = false;
    let alunoNome = "";

    setAlunos(prev => {
      const index = prev.findIndex(aluno => aluno.id === alunoId);

      if (index !== -1) {
        const alunosAtualizados = [...prev];
        const novaMateria: Materia = {
          ...materia,
          id: Date.now(),
        };

        alunosAtualizados[index] = {
          ...alunosAtualizados[index],
          materias: [...alunosAtualizados[index].materias, novaMateria],
        };

        alunoNome = alunosAtualizados[index].nome;
        sucesso = true;
        return alunosAtualizados;
      }

      return prev;
    });

    if (sucesso) {
      // Notificação para o administrador
      addNotification({
        title: "Disciplina Adicionada",
        message: `A disciplina ${materia.nome} foi adicionada para o aluno ${alunoNome}.`,
        type: "success",
      });

      // Notificação para o aluno
      addNotification({
        title: "Nova Disciplina",
        message: `A disciplina ${materia.nome} foi adicionada ao seu boletim.`,
        type: "info",
        link: "/boletim",
      });
    }

    return sucesso;
  };

  // Atualizar uma matéria de um aluno
  const updateMateria = (alunoId: string, materiaId: number, data: Partial<Materia>) => {
    let sucesso = false;
    let notaAtualizada = false;
    let nomeMateria = "";
    let nomeAluno = "";

    setAlunos(prev => {
      const alunoIndex = prev.findIndex(aluno => aluno.id === alunoId);

      if (alunoIndex !== -1) {
        const materiaIndex = prev[alunoIndex].materias.findIndex(m => m.id === materiaId);

        if (materiaIndex !== -1) {
          const alunosAtualizados = [...prev];
          const materiaAtual = alunosAtualizados[alunoIndex].materias[materiaIndex];

          // Verificar se uma nota foi alterada
          if (
            data.notas &&
            (data.notas.trimestre1 !== materiaAtual.notas.trimestre1 ||
             data.notas.trimestre2 !== materiaAtual.notas.trimestre2 ||
             data.notas.trimestre3 !== materiaAtual.notas.trimestre3)
          ) {
            notaAtualizada = true;
          }

          alunosAtualizados[alunoIndex].materias[materiaIndex] = {
            ...materiaAtual,
            ...data,
          };

          nomeMateria = materiaAtual.nome;
          nomeAluno = alunosAtualizados[alunoIndex].nome;
          sucesso = true;
          return alunosAtualizados;
        }
      }

      return prev;
    });

    if (sucesso) {
      // Notificação para o administrador
      addNotification({
        title: "Disciplina Atualizada",
        message: `Os dados da disciplina ${nomeMateria} do aluno ${nomeAluno} foram atualizados.`,
        type: "info",
      });

      // Notificação para o aluno sobre a atualização de notas
      if (notaAtualizada) {
        addNotification({
          title: "Notas Atualizadas",
          message: `Suas notas na disciplina ${nomeMateria} foram atualizadas.`,
          type: "info",
          link: "/boletim",
        });
      }
    }

    return sucesso;
  };

  // Excluir uma matéria de um aluno
  const deleteMateria = (alunoId: string, materiaId: number) => {
    let sucesso = false;
    let nomeMateria = "";
    let nomeAluno = "";

    setAlunos(prev => {
      const alunoIndex = prev.findIndex(aluno => aluno.id === alunoId);

      if (alunoIndex !== -1) {
        const materiaIndex = prev[alunoIndex].materias.findIndex(m => m.id === materiaId);

        if (materiaIndex !== -1) {
          const alunosAtualizados = [...prev];
          nomeMateria = alunosAtualizados[alunoIndex].materias[materiaIndex].nome;
          nomeAluno = alunosAtualizados[alunoIndex].nome;

          alunosAtualizados[alunoIndex] = {
            ...alunosAtualizados[alunoIndex],
            materias: alunosAtualizados[alunoIndex].materias.filter(m => m.id !== materiaId),
          };

          sucesso = true;
          return alunosAtualizados;
        }
      }

      return prev;
    });

    if (sucesso) {
      // Notificação para o administrador
      addNotification({
        title: "Disciplina Removida",
        message: `A disciplina ${nomeMateria} foi removida do boletim de ${nomeAluno}.`,
        type: "warning",
      });

      // Notificação para o aluno
      addNotification({
        title: "Disciplina Removida",
        message: `A disciplina ${nomeMateria} foi removida do seu boletim.`,
        type: "warning",
        link: "/boletim",
      });
    }

    return sucesso;
  };

  return (
    <StudentContext.Provider
      value={{
        alunos,
        getAlunoById,
        getAlunoByEmail,
        addAluno,
        updateAluno,
        deleteAluno,
        addMateria,
        updateMateria,
        deleteMateria,
      }}
    >
      {children}
    </StudentContext.Provider>
  );
}

// Hook para usar o contexto
export function useStudents() {
  const context = useContext(StudentContext);
  if (context === undefined) {
    throw new Error("useStudents deve ser usado dentro de um StudentProvider");
  }
  return context;
}
