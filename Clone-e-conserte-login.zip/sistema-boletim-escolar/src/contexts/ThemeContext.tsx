import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface ThemeContextType {
  darkMode: boolean;
  toggleDarkMode: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

interface ThemeProviderProps {
  children: ReactNode;
}

export function ThemeProvider({ children }: ThemeProviderProps) {
  // Verificar se o modo escuro está salvo no localStorage ou preferência do sistema
  const [darkMode, setDarkMode] = useState(() => {
    const savedTheme = localStorage.getItem("darkMode");

    if (savedTheme) {
      return savedTheme === "true";
    } else {
      // Verificar se o usuário prefere modo escuro no sistema
      return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
  });

  // Aplicar a classe 'dark' ao elemento html quando darkMode mudar
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }

    // Salvar configuração no localStorage
    localStorage.setItem("darkMode", darkMode.toString());
  }, [darkMode]);

  // Função para alternar entre modo claro e escuro
  const toggleDarkMode = () => {
    setDarkMode(prevMode => !prevMode);
  };

  return (
    <ThemeContext.Provider value={{ darkMode, toggleDarkMode }}>
      {children}
    </ThemeContext.Provider>
  );
}

// Hook personalizado para acessar o contexto de tema
export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error("useTheme deve ser usado dentro de um ThemeProvider");
  }
  return context;
}
