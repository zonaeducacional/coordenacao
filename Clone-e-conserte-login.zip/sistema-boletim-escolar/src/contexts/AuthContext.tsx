import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useStudents } from "./StudentContext";

export interface User {
  email: string;
  name: string;
  role: "admin" | "student";
  id?: string; // id do aluno, caso seja um estudante
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const { getAlunoByEmail } = useStudents();
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  // Verificar se o usuário já está autenticado ao carregar a página
  useEffect(() => {
    const storedAuth = localStorage.getItem("isAuthenticated");
    const storedUser = localStorage.getItem("user");

    if (storedAuth === "true" && storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
        setIsAuthenticated(true);
        setIsAdmin(parsedUser.role === "admin");
      } catch (error) {
        // Em caso de erro, limpe os dados locais
        localStorage.removeItem("isAuthenticated");
        localStorage.removeItem("user");
      }
    }
  }, []);

  // Função de login
  const login = async (email: string, password: string): Promise<boolean> => {
    // Verifica se é o administrador
    if (email === "admin@escola.com" && password === "123456") {
      const adminUser: User = {
        email,
        name: "Administrador",
        role: "admin"
      };
      setUser(adminUser);
      setIsAuthenticated(true);
      setIsAdmin(true);
      localStorage.setItem("isAuthenticated", "true");
      localStorage.setItem("user", JSON.stringify(adminUser));
      return true;
    }

    // Verifica se é um aluno
    const aluno = getAlunoByEmail(email);
    if (aluno && aluno.senha === password) {
      const studentUser: User = {
        email,
        name: aluno.nome,
        role: "student",
        id: aluno.id
      };
      setUser(studentUser);
      setIsAuthenticated(true);
      setIsAdmin(false);
      localStorage.setItem("isAuthenticated", "true");
      localStorage.setItem("user", JSON.stringify(studentUser));
      return true;
    }

    return false;
  };

  // Função de logout
  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    setIsAdmin(false);
    localStorage.removeItem("isAuthenticated");
    localStorage.removeItem("user");
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, isAdmin, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

// Hook personalizado para acessar o contexto de autenticação
export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth deve ser usado dentro de um AuthProvider");
  }
  return context;
}
